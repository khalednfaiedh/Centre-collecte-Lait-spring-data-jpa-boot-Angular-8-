package com.spark.collecteLait;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollecteLaitApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollecteLaitApplication.class, args);
	}

}
